// Local Server — SPDX-License-Identifier: GPL-3.0-or-later
//! Páginas do servidor: início (sites + arquivo), visualizador com zoom,
//! versões, confirmação de remoção. Nenhuma página tem script.

use std::fs;
use std::path::Path;

use crate::arquivo::{carimbo_legivel, Site};
use crate::http::segmentos_seguros;
use crate::textos::{self, t};
use crate::Servidor;

/// Páginas do servidor: sem nenhum script; formulários só para o próprio servidor.
pub const CSP_PAGINAS: &str = "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; frame-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'self'";

/// PDFs guardados abrem no leitor de PDF do navegador (que já roda isolado).
pub const CSP_PDF: &str = "default-src 'none'; frame-ancestors 'self'";

/// Cópias guardadas: caixa de areia, sem scripts, sem buscar nada fora do servidor.
pub const CSP_GUARDADO: &str = "sandbox allow-popups allow-popups-to-escape-sandbox; default-src 'self' data:; script-src 'none'; object-src 'none'; style-src 'self' 'unsafe-inline' data:; img-src 'self' data:; font-src 'self' data:; media-src 'self'; frame-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'";

pub fn escapar_html(t: &str) -> String {
    let mut s = String::with_capacity(t.len());
    for ch in t.chars() {
        match ch {
            '&' => s.push_str("&amp;"),
            '<' => s.push_str("&lt;"),
            '>' => s.push_str("&gt;"),
            '"' => s.push_str("&quot;"),
            '\'' => s.push_str("&#39;"),
            c => s.push(c),
        }
    }
    s
}

pub fn codificar_url(t: &str) -> String {
    let mut s = String::with_capacity(t.len());
    for b in t.bytes() {
        if b.is_ascii_alphanumeric() || b"-_.~".contains(&b) {
            s.push(b as char);
        } else {
            s.push_str(&format!("%{b:02X}"));
        }
    }
    s
}

/// Codifica uma chave guardada para virar caminho (mantém "/", "?" e "%").
fn caminho_da_chave(chave: &str) -> String {
    let mut s = String::new();
    for b in chave.bytes() {
        if b.is_ascii_alphanumeric() || b"-_.~/?=&%:+,;!$'()*@".contains(&b) {
            s.push(b as char);
        } else {
            s.push_str(&format!("%{b:02X}"));
        }
    }
    s
}

/// Lista as pastas dentro de sites/ (cada uma é um site).
pub fn listar_sites(raiz: &Path) -> Vec<String> {
    let mut nomes: Vec<String> = fs::read_dir(raiz)
        .map(|it| {
            it.filter_map(Result::ok)
                .filter(|e| e.path().is_dir())
                .filter_map(|e| e.file_name().into_string().ok())
                .filter(|n| segmentos_seguros(&format!("/{n}")).is_some())
                .collect()
        })
        .unwrap_or_default();
    nomes.sort_by_key(|n| n.to_lowercase());
    nomes
}

const ESTILO: &str = r#"
:root{--f:#15120e;--p:#1c1813;--e:#110e0a;--t:#e6dac0;--s:#9a8c72;--l:#c9a14a;--le:#6e5626;--v:#6fb09a;--r:#e0715a}
@media (prefers-color-scheme: light){:root{--f:#efe6d2;--p:#f7f0e1;--e:#fbf7ee;--t:#2a2117;--s:#74644a;--l:#8a6a1f;--le:#c5ab72;--v:#2f7a64;--r:#b23c25}}
*{box-sizing:border-box}
body{margin:0;background:var(--f);color:var(--t);font:15px/1.6 ui-monospace,"DejaVu Sans Mono",Consolas,monospace;padding:20px 16px}
main{max-width:1100px;margin:0 auto}
header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;padding-bottom:12px;border-bottom:1px dashed var(--le)}
h1{font-size:1.05rem;margin:0} h1 span{color:var(--l)}
.topo-dir{display:flex;align-items:center;gap:10px;flex-wrap:wrap} .topo-dir .botao{min-height:32px;padding:0 10px;font-size:.75rem}
.rede{color:var(--v);font-size:.85rem} code{color:var(--l);word-break:break-all}
.painel{position:relative;margin:30px 4px 0;padding:26px 16px 16px;background:var(--p);border:1px solid var(--le);outline:1px solid var(--le);outline-offset:3px}
.rotulo{position:absolute;top:-.85em;left:22px;padding:0 8px;background:var(--f);color:var(--l);font-size:.78rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase}
ul.lista{list-style:none;margin:0;padding:0;display:grid;gap:8px}
a.botao,button,.botao{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 14px;border:1px solid var(--l);background:transparent;color:var(--l);text-decoration:none;font:700 .85rem/1 ui-monospace,Consolas,monospace;cursor:pointer;border-radius:2px}
a.botao:hover,button:hover,a.botao:focus-visible,button:focus-visible{background:var(--l);color:var(--f);outline:none}
.principal{background:var(--l)!important;color:var(--f)!important}
.perigo{border-color:var(--r)!important;color:var(--r)!important}
.perigo:hover{background:var(--r)!important;color:var(--f)!important}
ul.lista a{display:block;padding:12px 14px;border:1px solid var(--l);color:var(--l);text-decoration:none;font-weight:700}
ul.lista a:hover{background:var(--l);color:var(--f)}
.vazio,.fraco{color:var(--s);margin:0}
form.guardar{display:flex;gap:8px;flex-wrap:wrap}
input[type=url]{flex:1 1 280px;min-height:44px;padding:0 12px;background:var(--e);color:var(--t);border:1px solid var(--le);font:15px ui-monospace,Consolas,monospace}
input[type=url]:focus{outline:2px solid var(--v)}
.msg{margin:10px 0 0;color:var(--v)} .msg.erro{color:var(--r)}
.grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px}
.cartao{border:1px solid var(--le);background:var(--e);display:flex;flex-direction:column}
.miniatura{position:relative;height:190px;overflow:hidden;border-bottom:1px solid var(--le);background:#fff}
.miniatura iframe{position:absolute;top:0;left:0;width:1280px;height:800px;border:0;transform:scale(.25);transform-origin:0 0;pointer-events:none}
.miniatura .icone{position:absolute;inset:0;display:grid;place-items:center;background:var(--p);color:var(--l);font-size:2rem;font-weight:700}
.cartao .info{padding:12px;display:grid;gap:4px;flex:1}
.cartao h3{margin:0;font-size:.95rem;line-height:1.35;overflow-wrap:anywhere}
.cartao .url{font-size:.78rem;color:var(--s);overflow-wrap:anywhere}
.cartao .estado{font-size:.8rem;color:var(--v)} .cartao .estado.erro{color:var(--r)}
.cartao .acoes{display:flex;flex-wrap:wrap;gap:6px;padding:0 12px 12px}
.cartao .acoes form{display:contents}
.cartao .acoes .botao,.cartao .acoes button{min-height:38px;padding:0 10px;font-size:.78rem}
.sobre p{margin:0 0 12px} .sobre p:last-child{margin:0} .sobre b{color:var(--l)}
dl{margin:0 0 12px} dt{color:var(--v);font-weight:700} dd{margin:0 0 8px 2ch;color:var(--s)}
.avisos li{margin-bottom:8px} .avisos ul{margin:0;padding-inline-start:2ch}
.idiomas{position:relative} .idiomas summary{list-style:none} .idiomas summary::-webkit-details-marker{display:none}
.idiomas nav{position:absolute;inset-inline-end:0;top:calc(100% + 6px);z-index:5;display:grid;grid-template-columns:1fr 1fr;gap:2px;min-width:300px;padding:8px;background:var(--p);border:1px solid var(--le);font-family:system-ui,sans-serif}
.idiomas nav a{padding:6px 8px;color:var(--t);text-decoration:none;font-size:.85rem} .idiomas nav a:hover,.idiomas nav a:focus-visible{background:var(--l);color:var(--f);outline:none}
.idiomas nav a[aria-current]{color:var(--l);font-weight:700}
[dir=rtl] .rotulo{left:auto;right:22px} [dir=rtl] dd{margin:0 2ch 8px 0}
footer{margin-top:24px;padding-top:12px;border-top:1px dashed var(--le);color:var(--s);font-size:.8rem}
"#;

fn pagina(titulo: &str, extra_head: &str, corpo: &str) -> String {
    format!(
        "<!doctype html>\n<html lang=\"{lang}\"{dir}><head><meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"color-scheme\" content=\"dark light\">\n<meta name=\"referrer\" content=\"no-referrer\">\n<title>{}</title>{extra_head}<style>{ESTILO}</style></head>\n<body>{corpo}</body></html>",
        escapar_html(titulo),
        lang = textos::atual().codigo(),
        dir = if textos::atual().direita_para_esquerda() { " dir=\"rtl\"" } else { "" }
    )
}

fn painel(rotulo: &str, classe: &str, conteudo: &str) -> String {
    format!("<section class=\"painel {classe}\"><span class=\"rotulo\">┤ {rotulo} ├</span>{conteudo}</section>")
}

fn endereco_da_versao(id: &str, ts: &str, chave: &str) -> String {
    format!("/arquivo/{}/{}/{}", codificar_url(id), codificar_url(ts), caminho_da_chave(chave))
}

/// Primeira versão/endereço inicial de um site guardado.
fn ultima(s: &Servidor, site: &Site) -> Option<(String, String)> {
    let arq = &s.gerente.arq;
    let ts = arq.versoes(&site.id).into_iter().next()?;
    let v = arq.versao(&site.id, &ts)?;
    Some((ts, v.inicio))
}

fn cartao(s: &Servidor, site: &Site, local: bool) -> String {
    let arq = &s.gerente.arq;
    let n_versoes = arq.versoes(&site.id).len();
    let ult = ultima(s, site);
    let titulo = if site.titulo.is_empty() { &site.url } else { &site.titulo };
    let miniatura = match (&ult, site.tipo.as_str()) {
        (Some((ts, ini)), "web" | "pagina") => format!(
            "<iframe src=\"{}\" sandbox=\"\" loading=\"lazy\" tabindex=\"-1\" aria-hidden=\"true\" title=\"\"></iframe>",
            escapar_html(&endereco_da_versao(&site.id, ts, ini))
        ),
        (Some(_), _) => "<div class=\"icone\">PDF</div>".to_string(),
        (None, _) => "<div class=\"icone\">…</div>".to_string(),
    };
    let progresso = s.gerente.progresso.lock().unwrap_or_else(|e| e.into_inner()).clone();
    let estado = match &progresso {
        Some(p) if p.id == site.id => format!(
            "<span class=\"estado\">{}</span>",
            t("baixando").replace("{p}", &p.paginas.to_string()).replace("{a}", &p.recursos.to_string()).replace("{mb}", &format!("{:.1}", p.bytes as f64 / 1_048_576.0))
        ),
        _ if s.gerente.na_fila(&site.id) => format!("<span class=\"estado\">{}</span>", t("fila")),
        _ if !site.erro.is_empty() => format!("<span class=\"estado erro\">● {}</span>", escapar_html(&textos::erro(&site.erro))),
        _ => match &ult {
            Some((ts, _)) => format!(
                "<span class=\"estado\">● {} · {n_versoes} {}</span>",
                carimbo_legivel(ts),
                if n_versoes == 1 { t("versao") } else { t("versoes") }
            ),
            None => format!("<span class=\"estado\">{}</span>", t("sem-copia")),
        },
    };
    let origem = match site.tipo.as_str() {
        "web" => escapar_html(&site.url),
        "pagina" => t("pagina-salva").to_string(),
        _ => t("documento").to_string(),
    };
    let mut acoes = String::new();
    if let Some((ts, ini)) = &ult {
        acoes.push_str(&format!(
            "<a class=\"botao principal\" href=\"/ver/{id}\">{}</a><a class=\"botao\" href=\"{}\">{}</a>",
            t("ampliar"),
            escapar_html(&endereco_da_versao(&site.id, ts, ini)),
            t("abrir"),
            id = codificar_url(&site.id)
        ));
        if n_versoes > 1 {
            acoes.push_str(&format!("<a class=\"botao\" href=\"/versoes/{}\">{}</a>", codificar_url(&site.id), t("versoes")));
        }
    }
    if local {
        if site.tipo == "web" && s.gerente.curl.disponivel {
            acoes.push_str(&format!(
                "<form method=\"post\" action=\"/acao\"><input type=\"hidden\" name=\"token\" value=\"{}\"><input type=\"hidden\" name=\"acao\" value=\"atualizar\"><input type=\"hidden\" name=\"id\" value=\"{}\"><button type=\"submit\">{}</button></form>",
                s.token,
                escapar_html(&site.id),
                t("atualizar")
            ));
        }
        acoes.push_str(&format!("<a class=\"botao perigo\" href=\"/remover/{}\">{}</a>", codificar_url(&site.id), t("remover")));
    }
    format!(
        "<article class=\"cartao\"><div class=\"miniatura\">{miniatura}</div><div class=\"info\"><h3>{}</h3><span class=\"url\">{origem}</span>{estado}</div><div class=\"acoes\">{acoes}</div></article>",
        escapar_html(titulo)
    )
}

pub fn inicial(s: &Servidor, local: bool, consulta: Option<&str>) -> String {
    let g = &s.gerente;
    let sites_pasta = listar_sites(&s.raiz);
    let mut lista = String::new();
    if sites_pasta.is_empty() {
        lista.push_str(&format!("<p class=\"vazio\">{}</p>", t("sem-sites")));
    } else {
        lista.push_str("<ul class=\"lista\">");
        for n in &sites_pasta {
            lista.push_str(&format!("<li><a href=\"/{}/\">&gt; {}</a></li>", codificar_url(n), escapar_html(n)));
        }
        lista.push_str("</ul>");
    }
    let rede = if s.config.compartilhar {
        let ends: Vec<String> = s.enderecos.iter().map(|e| format!("<code>http://{}:{}/</code>", escapar_html(e), s.config.porta)).collect();
        if ends.is_empty() { t("wifi").to_string() } else { format!("{}: {}", t("wifi-celular"), ends.join(" ")) }
    } else {
        t("so-aqui").to_string()
    };

    let guardados = g.arq.sites();
    let ocupado = g.progresso.lock().unwrap_or_else(|e| e.into_inner()).is_some() || !g.fila.lock().unwrap_or_else(|e| e.into_inner()).is_empty();
    let mut arquivo = String::new();
    if local {
        if g.curl.disponivel {
            arquivo.push_str(&format!(
                "<form class=\"guardar\" method=\"post\" action=\"/acao\"><input type=\"hidden\" name=\"token\" value=\"{}\"><input type=\"hidden\" name=\"acao\" value=\"adicionar\"><input type=\"url\" name=\"url\" required placeholder=\"{}\" aria-label=\"{}\"><button class=\"principal\" type=\"submit\">{}</button></form>",
                s.token,
                t("placeholder-url"),
                t("aria-url"),
                t("guardar")
            ));
        } else {
            arquivo.push_str(&format!("<p class=\"msg erro\">{}</p>", t("sem-curl")));
        }
        arquivo.push_str(&format!(
            "<p class=\"fraco\">{}</p>",
            t("importar").replace("{d}", &escapar_html(&g.arq.raiz.join("importar").display().to_string()))
        ));
    }
    if guardados.is_empty() {
        arquivo.push_str(&format!("<p class=\"vazio\" style=\"margin-top:12px\">{}</p>", t("nada")));
    } else {
        arquivo.push_str("<div class=\"grade\" style=\"margin-top:16px\">");
        for site in &guardados {
            arquivo.push_str(&cartao(s, site, local));
        }
        arquivo.push_str("</div>");
        arquivo.push_str(&format!(
            "<p class=\"fraco\" style=\"margin-top:12px\">{}</p>",
            t("total").replace("{n}", &guardados.len().to_string()).replace("{mb}", &format!("{:.1}", g.arq.tamanho_total() as f64 / 1_048_576.0))
        ));
    }

    let avisos = textos::avisos();
    // menu de idiomas sem script: cada nome é um link que guarda a escolha
    let atual = textos::atual();
    let mut idiomas = String::new();
    for (l, nome) in textos::Lingua::todas() {
        let marca = if l == atual { " aria-current=\"true\"" } else { "" };
        idiomas.push_str(&format!("<a href=\"/idioma/{}\" lang=\"{}\"{marca}>{nome}</a>", l.curto(), l.codigo()));
    }

    let mensagem = match consulta.and_then(|q| q.split('&').find_map(|p| p.strip_prefix("m="))) {
        Some("ok") => format!("<p class=\"msg\">{}</p>", t("m-ok")),
        Some("removido") => format!("<p class=\"msg\">{}</p>", t("m-removido")),
        Some("invalido") => format!("<p class=\"msg erro\">{}</p>", t("m-invalido")),
        _ => String::new(),
    };
    let corpo = format!(
        "<main><header><h1><span>~$</span> local-server</h1><span class=\"topo-dir\"><span class=\"rede\">{rede}</span><details class=\"idiomas\"><summary class=\"botao\" title=\"{}\">🌐 {}</summary><nav>{idiomas}</nav></details></span></header>{mensagem}{}{}{}{}<footer>{}</footer></main>",
        t("idioma"),
        atual.curto().to_uppercase(),
        painel(t("p-arquivo"), "", &arquivo),
        painel(t("p-sites"), "", &lista),
        painel(t("p-avisos"), "avisos sobre", &avisos),
        painel(t("p-sobre"), "sobre", &textos::sobre()),
        t("rodape"),
    );
    let refresh = if ocupado { "<meta http-equiv=\"refresh\" content=\"5\">" } else { "" };
    pagina("Local Server", refresh, &corpo)
}

/// Visualizador: a cópia em tela cheia, com zoom grande para quem enxerga pouco.
pub fn ver(s: &Servidor, id: &str, ts: Option<&str>, consulta: Option<&str>) -> String {
    let arq = &s.gerente.arq;
    let Some(site) = arq.site(id) else { return nao_existe() };
    let versoes = arq.versoes(id);
    let Some(ts) = ts.map(str::to_string).or_else(|| versoes.first().cloned()) else { return nao_existe() };
    let Some(v) = arq.versao(id, &ts) else { return nao_existe() };
    let zoom: u32 = consulta
        .and_then(|q| q.split('&').find_map(|p| p.strip_prefix("z=")))
        .and_then(|z| z.parse().ok())
        .filter(|z| [100, 125, 150, 200, 300].contains(z))
        .unwrap_or(100);
    let alvo = endereco_da_versao(id, &ts, &v.inicio);
    let base_ver = format!("/ver/{}/{}", codificar_url(id), codificar_url(&ts));
    let zooms: String = [100, 125, 150, 200, 300]
        .iter()
        .map(|z| {
            format!(
                "<a class=\"botao{}\" href=\"{base_ver}?z={z}\" aria-label=\"{}\">{z}%</a>",
                if *z == zoom { " principal" } else { "" },
                t("zoom-aria").replace("{z}", &z.to_string())
            )
        })
        .collect();
    let escala = zoom as f64 / 100.0;
    let quadro = if site.tipo == "documento" {
        format!("<iframe src=\"{}\" title=\"{}\" style=\"width:100%;height:100%;border:0\"></iframe>", escapar_html(&alvo), escapar_html(&site.titulo))
    } else {
        format!(
            "<iframe src=\"{}\" sandbox=\"allow-popups allow-popups-to-escape-sandbox\" title=\"{}\" style=\"width:{:.4}%;height:{:.4}%;border:0;transform:scale({escala});transform-origin:0 0;background:#fff\"></iframe>",
            escapar_html(&alvo),
            escapar_html(&site.titulo),
            100.0 / escala,
            100.0 / escala
        )
    };
    let online = match crate::baixar::original(&site, &v.inicio) {
        Some(o) => format!("<a class=\"botao\" href=\"{}\" rel=\"noreferrer noopener\" target=\"_blank\">{}</a>", escapar_html(&o), t("ver-online")),
        None => String::new(),
    };
    let outras = if versoes.len() > 1 { format!("<a class=\"botao\" href=\"/versoes/{}\">{} ({})</a>", codificar_url(id), t("versoes"), versoes.len()) } else { String::new() };
    let corpo = format!(
        "<div style=\"position:fixed;inset:0;display:flex;flex-direction:column\">\
<nav style=\"display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--le);background:var(--p)\">\
<a class=\"botao\" href=\"/\">{}</a><span style=\"flex:1 1 200px;font-weight:700;overflow-wrap:anywhere\">{} <span class=\"fraco\" style=\"font-weight:400\">· {}</span></span>\
<span class=\"fraco\">zoom:</span>{zooms}{outras}<a class=\"botao\" href=\"{}\">{}</a>{online}</nav>\
<div style=\"flex:1;overflow:hidden;position:relative\">{quadro}</div></div>",
        t("voltar"),
        escapar_html(if site.titulo.is_empty() { &site.url } else { &site.titulo }),
        carimbo_legivel(&ts),
        escapar_html(&alvo),
        t("tela-cheia")
    );
    pagina(&site.titulo, "", &corpo)
}

pub fn versoes(s: &Servidor, id: &str) -> String {
    let arq = &s.gerente.arq;
    let Some(site) = arq.site(id) else { return nao_existe() };
    let mut lista = String::from("<ul class=\"lista\">");
    for ts in arq.versoes(id) {
        lista.push_str(&format!("<li><a href=\"/ver/{}/{}\">&gt; {}</a></li>", codificar_url(id), codificar_url(&ts), carimbo_legivel(&ts)));
    }
    lista.push_str("</ul>");
    let corpo = format!(
        "<main><header><h1><span>~$</span> {}</h1><a class=\"botao\" href=\"/\">{}</a></header>{}</main>",
        t("versoes"),
        t("voltar"),
        painel(&escapar_html(if site.titulo.is_empty() { &site.url } else { &site.titulo }), "", &lista)
    );
    pagina(t("t-versoes"), "", &corpo)
}

pub fn confirmar_remocao(s: &Servidor, id: &str) -> String {
    let Some(site) = s.gerente.arq.site(id) else { return nao_existe() };
    let conteudo = format!(
        "<p>{}</p>\
<form method=\"post\" action=\"/acao\" style=\"display:flex;gap:8px;flex-wrap:wrap\"><input type=\"hidden\" name=\"token\" value=\"{}\"><input type=\"hidden\" name=\"acao\" value=\"remover\"><input type=\"hidden\" name=\"id\" value=\"{}\">\
<button class=\"perigo\" type=\"submit\">{}</button><a class=\"botao\" href=\"/\">{}</a></form>",
        t("remover-pergunta").replace("{t}", &escapar_html(if site.titulo.is_empty() { &site.url } else { &site.titulo })),
        s.token,
        escapar_html(id),
        t("sim-remover"),
        t("cancelar")
    );
    pagina(t("t-remover"), "", &format!("<main>{}</main>", painel(t("remover"), "sobre", &conteudo)))
}

pub fn nao_guardado(site: &Site, chave: &str, id: &str, ts: &str) -> String {
    let online = crate::baixar::original(site, chave)
        .map(|o| format!("<p><a class=\"botao\" href=\"{}\" rel=\"noreferrer noopener\" target=\"_blank\">{}</a></p>", escapar_html(&o), t("abrir-online")))
        .unwrap_or_default();
    let conteudo = format!(
        "<p>{}</p>{online}<p><a class=\"botao\" href=\"/ver/{}/{}\">{}</a></p>",
        t("nao-guardada"),
        codificar_url(id),
        codificar_url(ts),
        t("voltar-copia")
    );
    pagina(t("t-nao-guardada"), "", &format!("<main>{}</main>", painel(t("t-nao-guardada"), "sobre", &conteudo)))
}

fn nao_existe() -> String {
    let conteudo = format!("<p>{}</p><p><a class=\"botao\" href=\"/\">{}</a></p>", t("nao-existe"), t("voltar"));
    pagina(t("t-nao-existe"), "", &format!("<main>{}</main>", painel(t("t-nao-existe"), "sobre", &conteudo)))
}


pub fn tipo_do_arquivo(caminho: &Path) -> &'static str {
    let ext = caminho.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
    match ext.as_str() {
        "html" | "htm" => "text/html; charset=utf-8",
        "css" => "text/css; charset=utf-8",
        "js" | "mjs" => "text/javascript; charset=utf-8",
        "json" => "application/json",
        "webmanifest" => "application/manifest+json",
        "wasm" => "application/wasm",
        "txt" | "md" => "text/plain; charset=utf-8",
        "xml" => "application/xml",
        "svg" => "image/svg+xml",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "avif" => "image/avif",
        "ico" => "image/x-icon",
        "mp4" | "m4v" => "video/mp4",
        "webm" => "video/webm",
        "ogv" => "video/ogg",
        "mp3" => "audio/mpeg",
        "m4a" => "audio/mp4",
        "ogg" | "oga" | "opus" => "audio/ogg",
        "wav" => "audio/wav",
        "flac" => "audio/flac",
        "pdf" => "application/pdf",
        "epub" => "application/epub+zip",
        "woff2" => "font/woff2",
        "woff" => "font/woff",
        "ttf" => "font/ttf",
        "vtt" => "text/vtt; charset=utf-8",
        _ => "application/octet-stream",
    }
}

#[cfg(test)]
mod testes {
    use super::*;

    #[test]
    fn escapa_nomes_de_pastas() {
        assert_eq!(escapar_html("<script>\"x\"&'"), "&lt;script&gt;&quot;x&quot;&amp;&#39;");
        assert_eq!(codificar_url("Bíblia Sagrada"), "B%C3%ADblia%20Sagrada");
    }
}
